import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private userService: UserService) { }
  invalidCreds: boolean = false;

  ngOnInit(): void {
  }

  loginForm = new FormGroup({
    username: new FormControl('', [Validators.required, Validators.minLength(6)]),
    password: new FormControl('', [Validators.required, Validators.minLength(8)])
  })
  onLogin() {
    this.userService.loginUser(this.loginForm.value).subscribe(data => {
      this.success(data);
    }, error => {
      if (error.status == 200)
        this.success(error);
      else if (error.status == 401)
        this.invalidCreds = true;
      // console.log("Invalid Credentials!");
      else
        console.log("Something went wrong!");

    })
  }
  success(data:any) {
    localStorage.setItem('role',data.role);
    localStorage.setItem('token',data.token);
    this.invalidCreds = false;
    this.router.navigateByUrl("/home");
  }
}
