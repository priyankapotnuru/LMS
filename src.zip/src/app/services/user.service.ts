import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class UserService {
    // base_url = 'http://localhost:9092/api/v1.0/lms/company/';
    base_url = 'https://primary:1X9sgjnfY6yuQuTax3Dvmfkz5zYgroXpfoWV7e8uLPdTJPdg8SsvqqZJinVDnXhH@microspringapp.test.azuremicroservices.io/api-gateway/default/api/v1.0/lms/company/';
    headers = new HttpHeaders({
        'ResponseType': 'json',
        'Access-Control-Allow-Origin': '*',
    });

    constructor(private http: HttpClient) { }
    loginUser(user: any) {
        return this.http.post<any>(this.base_url + 'login', user);
    }
    registerUser(user: any): Observable<any> {
        return this.http.post<any>(this.base_url + 'register', user);
    }
    getUsers() {
        return this.http.get<any>(this.base_url + 'getAllUsers');
    }
}
function mode<T>(arg0: string, course: any, mode: any, arg3: string, arg4: { headers: HttpHeaders; }) {
    throw new Error('Function not implemented.');
}

