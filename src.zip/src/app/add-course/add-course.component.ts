import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CourseService } from '../services/course.service';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent implements OnInit {
  constructor(private courseService: CourseService, public dialogRef: MatDialogRef<AddCourseComponent>,
    @Inject(MAT_DIALOG_DATA) public anyVariable: any
  ) { console.log(anyVariable) }
  duplicateCourse = false;
  ngOnInit(): void {
  }
  courseForm = new FormGroup({
    course_id: new FormControl<number>(null),
    course_name: new FormControl<string>('', [Validators.required, Validators.minLength(20), Validators.maxLength(255), Validators.pattern('([A-Za-z]+[A-Za-z0-9,\\(\\)\\[\\]\\{\\}\"\\:./_\\s]|(?<!-)-)*')]),
    course_description: new FormControl<string>('', [Validators.required, Validators.minLength(100), Validators.maxLength(255), Validators.pattern('([A-Za-z]+[A-Za-z0-9,\\(\\)\\[\\]\\{\\}\"\\:./_\\s]|(?<!-)-)*')]),
    technology: new FormControl<string>('', [Validators.required, Validators.maxLength(255), Validators.pattern('([A-Za-z0-9,\\(\\)\\[\\]\\{\\}\"\\:./_#\\s]|(?<!-)-)*')]),
    course_duration: new FormControl<number>(null, [Validators.required, Validators.maxLength(6)]),
    launch_url: new FormControl<string>('', [Validators.required, Validators.maxLength(255)])
  })
  onCancel() {
    this.dialogRef.close();
  }
  onSubmit() {
    this.courseService.addCourse(this.courseForm.value).subscribe(
      data => {
        this.success();
      },
      error => {
        if (error.status == 200) {
          this.success();
        } else if (error.status == 400 && error.error == 'Error: Course already exists!') {
          this.duplicateCourse = true;
        }
      }
    )
  }
  success() {
    this.duplicateCourse = false;
    alert('Course added successfully!');
    this.onCancel();
  }
}
