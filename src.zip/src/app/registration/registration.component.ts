import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }
  success = false;
  userExists = false;
  ngOnInit(): void {
  }
  registrationForm = new FormGroup({
    username: new FormControl('', [Validators.required, Validators.minLength(6)]),
    email: new FormControl('', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')]),
    password: new FormControl('', [Validators.required, Validators.minLength(8)])
  })
  onRegistration() {
    this.userService.registerUser(this.registrationForm.value).subscribe(data => {
      this.successFun();
    }, error => {
      if (error.status == 200)
        this.successFun();
      else if (error.status == 400) {
        this.success = false;
        this.userExists = true;
      }
    })
  }
  successFun() {
    this.success = true;
    this.userExists = false;
  }
  onCancel() {
    this.router.navigateByUrl("/login");
  }

}
