package com.estockmarket.company.query.api.queries;

import com.estockmarket.cqrscore.queries.BaseQuery;

public class FindAllCompaniesQuery extends BaseQuery{

}
