package com.estockmarket.cqrscore.domain;

public abstract class BaseEntity {

}
