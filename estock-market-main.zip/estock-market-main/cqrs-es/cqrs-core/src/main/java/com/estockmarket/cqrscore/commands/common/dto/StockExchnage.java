package com.estockmarket.cqrscore.commands.common.dto;

public enum StockExchnage {
	BSE, NSE
}
