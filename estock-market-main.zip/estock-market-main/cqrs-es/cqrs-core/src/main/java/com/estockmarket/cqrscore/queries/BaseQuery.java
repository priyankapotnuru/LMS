package com.estockmarket.cqrscore.queries;

public abstract class BaseQuery {

}
