package com.estockmarket.cqrscore.exceptions;

public class ConcurrencyException  extends RuntimeException{

}
