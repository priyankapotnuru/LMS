package com.demo.LMS.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.demo.LMS.Entity.Course;
import com.demo.LMS.Repository.CourseRepository;
import com.demo.LMS.VO.CourseVO;

@Service
public class CourseService {
	@Autowired
	private CourseRepository courseRepo;

	public ResponseEntity<?> addCourse(CourseVO course, String course_name) {
		if (!course.getCourse_name().equals(course_name)) {
			return ResponseEntity.badRequest().body(new String("Error: Invalid course!"));
		}
		if (course.getCourse_id() != null) {
			if (courseRepo.getCourseCountByid(course.getCourse_name(), course.getCourse_id()) != 0) {
				return ResponseEntity.badRequest().body(new String("Error: Course already exists!"));
			} else {
				Optional<Course> oldCourse = courseRepo.findById(course.getCourse_id());
				if (oldCourse.isPresent()) {
					Course newCourse = oldCourse.get();
					newCourse.setCourse_name(course.getCourse_name());
					newCourse.setCourse_description(course.getCourse_description());
					newCourse.setTechnology(course.getTechnology());
					newCourse.setCourse_duration(course.getCourse_duration());
					newCourse.setLaunch_url(course.getLaunch_url());
					courseRepo.save(newCourse);
					return ResponseEntity.ok().body(new String("Course added successfully!"));
				} else {
					return ResponseEntity.badRequest().body(new String("Error: Course is Missing!"));
				}
			}
		} else {
			if (courseRepo.getCourseCount(course.getCourse_name()) != 0) {
				return ResponseEntity.badRequest().body(new String("Error: Course already exists!"));
			} else {
				Course newCourse = new Course(course.getCourse_name(), course.getCourse_duration(),
						course.getCourse_description(), course.getTechnology(), course.getLaunch_url());
				courseRepo.save(newCourse);
				return ResponseEntity.ok().body(new String("Course added successfully!"));
			}
		}
	}

	public List<Course> getCourseDetails(String technology) {
		List<Course> courses = null;
		if (technology != null) {
			courses = (List<Course>) courseRepo.getCoursesByTechnology(technology);
		} else {
			courses = (List<Course>) courseRepo.findAll();
		}
		return courses;
	}

	public List<Course> getCourseDetailsByDuration(String technology, long from_duration, long to_duration) {
		return courseRepo.getCoursesByDuration(technology, from_duration, to_duration);
	}

	public ResponseEntity<?> deleteCourse(String course_name) {
		Long course_id = courseRepo.getCourseId(course_name);
		if (course_id != null) {
			courseRepo.deleteById(course_id);
			return ResponseEntity.ok().body(new String("Course deleted successfully!"));
		} else {
			return ResponseEntity.badRequest().body(new String("Error: Course does not exists!"));
		}
	}

}
