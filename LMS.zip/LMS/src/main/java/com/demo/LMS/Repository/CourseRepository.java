package com.demo.LMS.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.demo.LMS.Entity.Course;

public interface CourseRepository extends CrudRepository<Course, Long> {

	@Query(value = "select * from course where technology=(?1)", nativeQuery = true)
	public List<Course> getCoursesByTechnology(String technology);

	@Query(value = "select * from course where technology=(?1) and course_duration>=(?2) and course_duration<=(?3)", nativeQuery = true)
	public List<Course> getCoursesByDuration(String technology, long from, long to);

	@Query(value = "select count(*) from course where course_name=(?1)", nativeQuery = true)
	public long getCourseCount(String course_name);

	@Query(value = "select count(*) from course where course_name=(?1) and course_id!=(?2)", nativeQuery = true)
	public long getCourseCountByid(String course_name, Long course_id);

	@Query(value = "select course_id from course where course_name=(?1)", nativeQuery = true)
	public Long getCourseId(String course_name);

}
