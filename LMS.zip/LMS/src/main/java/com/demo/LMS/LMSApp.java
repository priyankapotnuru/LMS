package com.demo.LMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class LMSApp {
	public static void main(String[] args) {
		SpringApplication.run(LMSApp.class, args);
	}
}