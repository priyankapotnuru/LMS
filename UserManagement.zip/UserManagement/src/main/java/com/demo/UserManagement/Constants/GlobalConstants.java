package com.demo.UserManagement.Constants;

public class GlobalConstants {
	public static final String ADMIN = "Admin";
	public static final String User = "User";
}
