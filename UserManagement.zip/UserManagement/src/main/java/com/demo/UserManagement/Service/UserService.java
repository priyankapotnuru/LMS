package com.demo.UserManagement.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.demo.UserManagement.Constants.GlobalConstants;
import com.demo.UserManagement.Entity.SignUpVO;
import com.demo.UserManagement.Entity.User;
import com.demo.UserManagement.Repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepo;

	public List<User> getUsers() {
		List<User> userDetails = new ArrayList<User>();
		userDetails = (List<User>) userRepo.findAll();
		return userDetails;
	}

	public ResponseEntity<?> signUp(SignUpVO signup) {
		if (userRepo.getUserNameCount(signup.getUsername()) != 0) {
			return ResponseEntity.badRequest().body(new String("Error: Username is already taken!"));
		} else if (userRepo.getEmailCount(signup.getEmail()) != 0) {
			return ResponseEntity.badRequest().body(new String("Error: Email is already in use!"));
		} else {
			User user = new User(signup.getUsername(), signup.getEmail(), signup.getPassword());
			user.setRole(userRepo.count() == 0 ? GlobalConstants.ADMIN : GlobalConstants.User);
			userRepo.save(user);
			return ResponseEntity.ok().body(new String("User registered successfully!"));
		}
	}

	public boolean validateUser(String username, String password) {
		User user = userRepo.validateUser(username, password);
		return user != null ? true : false;
	}

}
