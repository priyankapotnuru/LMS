package com.demo.UserManagement.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.UserManagement.Entity.User;
import com.demo.UserManagement.Service.UserService;

@RestController
@RequestMapping("api/v1.0/lms/company")
public class UserController {
	@Autowired
	private UserService userService;

	@GetMapping("/getAllUsers")
	public ResponseEntity<?> getUserDetails() {
		List<User> users = userService.getUsers();
		return (users != null && users.size() != 0) ? new ResponseEntity<List<User>>(users, HttpStatus.OK)
				: new ResponseEntity<String>("No users registered yet!", HttpStatus.NO_CONTENT);
	}
}
