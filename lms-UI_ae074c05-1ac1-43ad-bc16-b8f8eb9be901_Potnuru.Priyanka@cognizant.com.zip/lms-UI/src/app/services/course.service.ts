import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  base_url = 'http://localhost:9092/api/v1.0/lms/courses/';
  headers = new HttpHeaders({
    // 'ResponseType': 'json',
    // 'Access-Control-Allow-Origin': '*',

  });

  constructor(private http: HttpClient) { }
  getAllCourses() {
    return this.http.get<any>(this.base_url + 'getall');
    // return this.http.get<any>('http://localhost:9092/api/v1.0/lms/company/getAllUsers');
  }
  getCoursesByTechnology(technology: String) {
    return this.http.get<any>(this.base_url + 'info/' + technology);
  }
  getCoursesByTechnologyDuration(technology: String, start_duration: number, end_duration: number) {
    return this.http.get<any>(this.base_url + 'get/' + technology + '/' + start_duration + '/' + end_duration);
  }
  addCourse(course: any): Observable<any> {
    return this.http.post<any>(this.base_url + 'add/' + course.course_name, course
    // , { 'headers': this.headers }
    );
  }
  deleteCourse(course_name: String) {
    return this.http.delete<any>(this.base_url + 'delete/' + course_name);
  }
}
function mode<T>(arg0: string, course: any, mode: any, arg3: string, arg4: { headers: HttpHeaders; }) {
  throw new Error('Function not implemented.');
}

