class Course {
    course_id!: number;
    course_name!: string;
    course_description!: string;
    technology!: string;
    course_duration!: number;
    launch_url!: string;
}