import { DialogRef } from '@angular/cdk/dialog';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CourseService } from '../services/course.service';

@Component({
  selector: 'app-edit-course',
  templateUrl: './edit-course.component.html',
  styleUrls: ['./edit-course.component.css']
})
export class EditCourseComponent implements OnInit {
  courseForm = new FormGroup({
    course_id: new FormControl<number>(this.data.course_id),
    course_name: new FormControl<string>(this.data.course_name, [Validators.required, Validators.minLength(20), Validators.maxLength(255)
      // , Validators.pattern('([A-Za-z]+[A-Za-z0-9,\\(\\)\\[\\]\\{\\}\"\\:./_\\s]|(?<!-)-)*')
    ]),
    course_description: new FormControl<string>(this.data.course_description, [Validators.required, Validators.minLength(100), Validators.maxLength(255)
      // , Validators.pattern('([A-Za-z]+[A-Za-z0-9,\\(\\)\\[\\]\\{\\}\"\\:./_\\s]|(?<!-)-)*')
    ]),
    technology: new FormControl<string>(this.data.technology, [Validators.required, Validators.maxLength(255)
      // , Validators.pattern('([A-Za-z0-9,\\(\\)\\[\\]\\{\\}\"\\:./_#\\s]|(?<!-)-)*')
    ]),
    course_duration: new FormControl<number>(this.data.course_duration, [Validators.required, Validators.maxLength(6)]),
    launch_url: new FormControl<string>(this.data.launch_url, [Validators.required, Validators.maxLength(255)])
  })
  duplicateCourse: boolean = false;

  constructor(private dialogRef: MatDialogRef<EditCourseComponent>, private courseService: CourseService, @Inject(MAT_DIALOG_DATA) public data: any) {
    console.log(data);
  }

  ngOnInit(): void {
  }
  onCancel() {
    this.dialogRef.close();
  }
  success() {
    this.duplicateCourse = false;
    alert('Course updated successfully!');
    this.onCancel();
  }
  onSubmit() {
    this.courseService.addCourse(this.courseForm.value).subscribe(
      data => {
        this.success();
      },
      error => {
        if (error.status == 200) {
          this.success();
        } else if (error.status == 400 && error.error == 'Error: Course already exists!') {
          this.duplicateCourse = true;
        }
      }
    )
  }

}
