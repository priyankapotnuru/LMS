import { Component, OnInit } from '@angular/core';
import { CourseService } from '../services/course.service';
import { MatDialog } from '@angular/material/dialog';
import { AddCourseComponent } from '../add-course/add-course.component';
import { EditCourseComponent } from '../edit-course/edit-course.component';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  courses: any[] = [];
  technology: String = '';
  start_duration: number;
  end_duration: number;
  role = localStorage.getItem('role');

  constructor(private courseService: CourseService, private matDialog: MatDialog) { }

  ngOnInit(): void {
    this.getCourses();
  }
  getCourses() {
    this.courseService.getAllCourses().subscribe(
      data => {
        this.courses = data;
      }
    );
  }
  onAddNew() {
    this.matDialog.open(AddCourseComponent, {
      "width": '40%',
      "maxHeight": '80%',
      "data": "John",
      "autoFocus": false
    })
      .afterClosed().subscribe(result => {
        this.getCourses();
      });
  }
  EditCourse(course: any) {
    console.log(course + "Edited");
    this.matDialog.open(EditCourseComponent, {
      "width": '40%',
      "maxHeight": '80%',
      "data": course,
      "autoFocus": false
    })
      .afterClosed().subscribe(result => {
        this.getCourses();
      });
  }

  DeleteCourse(course_name: String) {
    this.courseService.deleteCourse(course_name).subscribe(
      data => {
        this.getCourses();
      }, error => {
        if (error.status == 200) {
          console.log('Course deleted successfully!');
          this.getCourses();
        } else if (error.status == 400) {
          console.log('Error deleting the course!');
        }
      }
    );
  }
  onSearch() {
    this.courseService.getCoursesByTechnology(this.technology).subscribe(
      data => {
        this.courses = data;
      }
    );
  }
  onFilter() {
    this.courseService.getCoursesByTechnologyDuration(this.technology, this.start_duration, this.end_duration).subscribe(
      data => {
        this.courses = data;
      }
    );
  }
}
